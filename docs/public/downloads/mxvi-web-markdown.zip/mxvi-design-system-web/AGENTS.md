# MXVI Design System — Web

Local copy of the MXVI design system for **web** interfaces.
Treat these files as the design contract for any user-facing UI in this project.

## Read in this order

1. `ai/agent-instructions.md` — behavioral contract for agents.
2. `catalog/visual-dna.md` — the traits that make something look MXVI (identical to moisesbaldenegro.com).
3. `platforms/web/index.md` — platform summary and compact agent contract.
4. `catalog/` — every component with its exact visual spec and reference HTML.
5. The rest of `platforms/web/`, plus `foundations/`, `brand/` and `guidelines/` as needed.

A ready-to-paste prompt is in `catalog/master-prompt.md`.

`llms-web.txt` contains all of the above in a single file.

## Links and assets

- Links that start with `/` point to files in this folder: `/foundations/colors` is `foundations/colors.md`.
- The official logo SVGs are in `brand/assets/` and `mxvi/assets/`. Never rebuild the logo with a font.
- `mxvi/mxvi.css` is the real stylesheet (fonts, tokens, base and `.mx-*` components); `mxvi/mxvi.js` adds optional behaviors.
- In web projects link `mxvi/mxvi.css`; in other technologies reproduce the values in the catalog specs.

## Report

When you finish UI work, report: platform (web), tokens used,
components and patterns reused, responsive or adaptive behavior, accessibility
considerations, and any deviation or proposed addition.
