# MXNI Design System — Desktop

Local copy of the MXNI design system for **desktop** interfaces.
Treat these files as the design contract for any user-facing UI in this project.

## Read in this order

1. `ai/agent-instructions.md` — behavioral contract for agents.
2. `platforms/desktop/index.md` — platform summary and compact agent contract.
3. The rest of `platforms/desktop/` as needed: layout, navigation, components, interaction, checklist.
4. `foundations/`, `components/`, `brand/` and `guidelines/` for detailed rules.
5. `implementation/css-tokens.md` for the canonical token values.

`llms-desktop.txt` contains all of the above in a single file.

## Links and assets

- Links that start with `/` point to files in this folder: `/foundations/colors` is `foundations/colors.md`.
- The official logo SVGs are in `brand/assets/`. Never rebuild the logo with a font.

## Report

When you finish UI work, report: platform (desktop), tokens used,
components and patterns reused, responsive or adaptive behavior, accessibility
considerations, and any deviation or proposed addition.
