# MXNI Design System — Desktop

Local copy of the MXNI design system for **desktop** interfaces.
Treat these files as the design contract for any user-facing UI in this project.

## Read in this order

1. `ai/agent-instructions.md` — behavioral contract for agents.
2. `catalog/visual-dna.md` — the traits that make something look MXNI (identical to moisesbaldenegro.com).
3. `platforms/desktop/index.md` — platform summary and compact agent contract.
4. `catalog/` — every component with its exact visual spec and reference HTML.
5. The rest of `platforms/desktop/`, plus `foundations/`, `brand/` and `guidelines/` as needed.

A ready-to-paste prompt is in `catalog/master-prompt.md`.

`llms-desktop.txt` contains all of the above in a single file.

## Links and assets

- Links that start with `/` point to files in this folder: `/foundations/colors` is `foundations/colors.md`.
- The official logo SVGs are in `brand/assets/` and `mxni/assets/`. Never rebuild the logo with a font.
- `mxni/mxni.css` is the real stylesheet (fonts, tokens, base and `.mx-*` components); `mxni/mxni.js` adds optional behaviors.
- In web projects link `mxni/mxni.css`; in other technologies reproduce the values in the catalog specs.

## Report

When you finish UI work, report: platform (desktop), tokens used,
components and patterns reused, responsive or adaptive behavior, accessibility
considerations, and any deviation or proposed addition.
